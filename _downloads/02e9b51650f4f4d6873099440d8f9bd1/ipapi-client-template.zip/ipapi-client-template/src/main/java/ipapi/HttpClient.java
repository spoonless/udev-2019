package ipapi;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

import org.glassfish.jersey.logging.LoggingFeature;


/**
 * Exemple d'utilisation de l'API Web de ip-api (http://ip-api.com/docs/)
 */
public class HttpClient {

	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		// activation des logs pour voir la requête et la réponse dans la console
		client.property(LoggingFeature.LOGGING_FEATURE_LOGGER_LEVEL_CLIENT, "INFO");

    // TODO réaliser un appel à l'API ip-api
	}
}
